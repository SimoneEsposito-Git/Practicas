package testers;

import blockchain.*;
import blockchain.utils.*;
import exception.*;

/**
 * Clase para probar el ejercicio 2
 * 
 * @author Lin Qi y Simone Esposito
 */
public class OwnTesterExercise2 extends OwnTesterExercise1 {
    /**
     * Chequea si lanza bien las excepciones en connect
     */
    public void connectExceptions() {
        try {
            this.network.connect(this.node0);
        }
        catch (NodeConnectionException e) {
            System.err.println(e);
        }
        try {
            this.network.connect(this.mnode1);
        }
        catch (NodeConnectionException e) {
            System.err.println(e);
        }
    }

    /**
     * Chequea su lanza bien las excepciones de transacciones
     */
    public void transactionExceptions() {
        try {
            Transaction tr2 = new Transaction(this.mnode1.getWallet(), this.mnode2.getWallet(), -1);
        }
        catch (TransactionException e) {
            System.err.println(e);
        }
        try {
            this.mnode4.createTransaction(this.mnode1.getWallet(), 450);
        }
        catch (TransactionException e) {
            System.err.println(e);
        }
    }

    /**
     * Main que se ejecuta y se chequean las salidas
     * 
     * @param args entradas de main
     */
    public static void main(String args[]) {
        OwnTesterExercise2 tester2 = new OwnTesterExercise2();
        tester2.initialize();
        tester2.connectExceptions();
        tester2.transactionExceptions();
        System.out.println("End");
    }
}
