package testers;

import blockchain.*;
import blockchain.utils.*;
import exception.NodeConnectionException;
import exception.TransactionException;

/**
 * Clase para probar ejercicio 1
 * 
 * @author eps
 */
public class TesterMainExercise1 {
    /**
     * Wallets
     */
    protected Wallet wallet1, wallet2, wallet3;
    /**
     * Nodos minadores
     */
    protected MiningNode miningNode, miningNode2;
    /**
     * Nodo
     */
    protected Node node;
    /**
     * Subred
     */
    protected Subnet subnet;
    /**
     * Network general
     */
    protected BlockchainNetwork network;

    /**
     * Construye los atributos
     */
    public void buildNetwork() {
        //Create the wallets
        this.wallet1 = new Wallet("Bob", CommonUtils.sha1("PK-Bob"), 10);
        this.wallet2 = new Wallet("Alice", CommonUtils.sha1("PK-Alice"), 100);
        this.wallet3 = new Wallet("Paul", CommonUtils.sha1("PK-Pauk"), 777);

        //Create the nodes with the wallets
        node = new Node(wallet1);
        miningNode = new MiningNode(wallet2, 10000);

        //Create a subnet inside a network
        miningNode2 = new MiningNode(wallet3, 10000);
        subnet = new Subnet(miningNode2); // we could pass more nodes here

        //Create the network and connect the elements
        this.network = new BlockchainNetwork("ADSOF blockchain");
        try {
            network.connect(node)
                    .connect(subnet)
                    .connect(miningNode);
        }
        catch(NodeConnectionException e) {

        }

        //create example transaction, which transfers 10 coins from wallet1 to wallet2
        try {
        new Transaction(wallet1, wallet2, 10);
        }
        catch(TransactionException e) {
            
        }
    }

    /**
     * Main que se ejecuta
     * 
     * @param args entradas de main
     */
    public static void main(String[] args) {
        TesterMainExercise1 tme = new TesterMainExercise1();
        tme.buildNetwork();
        System.out.println(tme.network);
        System.out.println(tme.node.fullName()); // prints the name of the node
        System.out.println("End of party!");
        }
    }
    