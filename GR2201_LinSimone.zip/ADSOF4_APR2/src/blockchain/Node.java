package blockchain;

import java.util.*;

import exception.*;

/**
 * Un nodo tiene asociado un wallet y sus transactions
 * 
 * @author Lin Qi y Simone Esposito
 */
public class Node extends BlockchainElement{
    private Wallet wallet;
    private List<Transaction> transactions;

    /**
     * Constrcutor de nodo
     * 
     * @param wallet el wallet que esta relacionado con el nodo
     */
    public Node(Wallet wallet) {
        this.wallet = wallet;
        this.transactions = new ArrayList<>();
    }

    /**
     * Devuelve el nombre completo de un node
     * 
     * @return el nombre completo de un nodo
     */
    public String fullName() {
        return "Node#"+this.getId();
    }

    /**
     * Devuelve el wallet
     * 
     * @return el wallet
     */
    public Wallet getWallet() {
        return this.wallet;
    }

    /**
     * Anyade una transaccion al nodo
     * 
     * @param transaction la transaccion que se va a anydir
     */
    public void addTransaction(Transaction transaction) {
        this.transactions.add(transaction);
    }

    /**
     * Crear una transaccion del nodo actual
     * 
     * @param receptor el wallet receptor de la transaccion
     * @param cantidad el balance que se va a enviar
     * @throws TransactionException excepcion de transacccion
     * @return la transaccion que se ha generado
     */
    public Transaction createTransaction(Wallet receptor, int cantidad) throws TransactionException {
        return this.createTransaction(receptor.getPublicKey(), cantidad);
    }

    /**
     * Crear una transaccion del nodo actual
     * 
     * @param receptor el receptor de la transaccion
     * @param cantidad el balance que se va a enviar
     * @throws TransactionException excepcion de transaccion 
     * @return la transaccion que se ha generado
     */
    public Transaction createTransaction(String receptor, int cantidad) throws TransactionException {
        return new Transaction(this.wallet, receptor, cantidad);
    }

    /**
     * Distribuye el proceso del nodo
     * 
     * @param msg el mensaje que va a distribuir
     */
    @Override
    public void broadcast(IMessage msg) {
        msg.process(this);
    }

    /**
     * Devuelve la informacion de un nodo
     * 
     * @return una linea de texto de la informacion de un nodo
     */
    @Override
    public String toString() {
        return this.wallet+ " | @Node#"+ this.getId();
    }
}
