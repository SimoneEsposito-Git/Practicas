package blockchain;

import java.util.*;

import exception.*;

/**
 * Un blockchain network
 * 
 * @author Lin Qi y Simone Esposito
 */
public class BlockchainNetwork implements IConnectable{
    private String nombre;
    private List<BlockchainElement> elementos;

    /**
     * Constructor de blockchain network
     * 
     * @param nombre el nombre del network
     */
    public BlockchainNetwork(String nombre) {
        this.nombre = nombre;
        this.elementos = new ArrayList<>();
    }

    /**
     * Conecta a un nodo
     * 
     * @param node el nodo que se va a conectar
     * @return si mismo si se ha anyadido correctamente, null en caso contrario
     * @throws ConnectionException exception de nodo ya metido en esta red
     * @throws DuplicateConnectionException exception de nodo ya metido en otra red
     */
    public BlockchainNetwork connect(Node node) throws ConnectionException, DuplicateConnectionException {
        if (node.getParent() != null) {
            if (node.getParent() == this) {
                throw new ConnectionException(node);
            }
            else {
                throw new DuplicateConnectionException(node);
            }
        }
        this.elementos.add(node);
        node.setPadre(this);
        System.out.println(this.nombre+" - new peer connected: "+node);
        return this;
    }

    /**
     * Conecta a una subred
     * 
     * @param subnet la subred que se va a conectar
     * @return si mismo si se ha anyadido correctament, null en caso contrario
     */
    public BlockchainNetwork connect(Subnet subnet) {
        if (subnet.getParent() != null) {
            return null;
        }
        subnet.setPadre(this);
        this.elementos.add(subnet);
        System.out.println(this.nombre+"- new peer connected: "+subnet);
        return this;
    }

    /**
     * Distribuye el mensaje a los nodos
     * 
     * @param msg el mensaje
     */
    @Override
    public void broadcast(IMessage msg) {
        for (BlockchainElement element: this.elementos) {
            element.broadcast(msg);
        }
    }

    /**
     * Devuelve el padre de blockchain network
     * 
     * @return null
     */
    @Override
    public IConnectable getParent() {
        return null;
    }

    /**
     * Devuelve la informacion de un blockchain network
     * 
     * @return un string que contiene la informacion de un blockchain network
     */
    @Override
    public String toString() {
        String str = this.nombre+" consists of "+this.elementos.size()+" elements:\n";
        for (BlockchainElement element: this.elementos) {
            str += "* "+element+"\n";
        }
        return str;
    }
}