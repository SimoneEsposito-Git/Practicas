package testers;

import blockchain.*;
import blockchain.utils.*;
import exception.*;

/**
 * Clase para chequear el ejercicio 3
 */
public class OwnTesterExercise3 extends OwnTesterExercise1 {
    /**
     * Envia mensaje por toda la res para chequear su funcionalidad
     */
    public void sendMessage() {
        this.mnode1.setMiningMethod(new SimpleMining());
        this.mnode1.setValidationMethod(new SimpleValidate());
        this.mnode2.setMiningMethod(new SimpleMining());
        this.mnode2.setValidationMethod(new SimpleValidate());
        this.mnode4.setMiningMethod(new SimpleMining());
        this.mnode4.setValidationMethod(new SimpleValidate());
        this.network.broadcast(new TransactionNotification(this.tr1));
        System.out.println(this.mnode1);
        System.out.println(this.mnode2);
    }

    /**
     * Main que se ejecuta
     * 
     * @param args entradas de main
     */
    public static void main(String args[]) {
        OwnTesterExercise3 tester3 = new OwnTesterExercise3();
        tester3.initialize();
        tester3.sendMessage();
        System.out.println("End");
    }
}
