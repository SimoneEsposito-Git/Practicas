package testers;

import testers.*;
import blockchain.*;
import exception.TransactionException;

/**
 * Clase para probar el ejercicio 3
 * 
 * @author eps
 */
public class TesterMainExercise3 extends TesterMainExercise2{
    /**
     * Prueba el ejercicio 3
     */
    public void createTransactions(){
    //create a transaction and send it to the network
        this.miningNode.setMiningMethod(new SimpleMining());
        this.miningNode.setValidationMethod(new SimpleValidate());
        this.miningNode2.setMiningMethod(new SimpleMining());
        this.miningNode2.setValidationMethod(new SimpleValidate());
        try {
        network.broadcast(new TransactionNotification(
        node.createTransaction(wallet2.getPublicKey(), 5)));
        }
        catch(TransactionException e) {
            System.err.println(e);
        }
    }

    /**
     * Main que se ejecuta
     * 
     * @param args entradas de main
     */
    public static void main(String[] args) {
        TesterMainExercise3 tme = new TesterMainExercise3();
        tme.buildNetwork();
        tme.createTransactions();
        System.out.println("End of party!");
    }
}
    