package testers;

import blockchain.*;
import blockchain.utils.*;
import exception.*;

/**
 * Clase para examinar el ejercicio 1
 * 
 * @author Lin Qi y Simone Esposito
 */
public class OwnTesterExercise1 {
    /**
     * Network general
     */
    protected BlockchainNetwork network;
    /**
     * Nodo
     */
    protected Node node0;
    /**
     * Nodo minador
     */
    protected MiningNode mnode1;
    /**
     * Nodo minador
     */
    protected MiningNode mnode2;
    /**
     * Subred
     */
    protected Subnet net3;
    /**
     * Nodo minador
     */
    protected MiningNode mnode4;
    /**
     * Transaccion
     */
    protected Transaction tr1;

    /**
     * Inicializa los valores de los atributos
     */
    public void initialize() {
        this.network = new BlockchainNetwork("Propio network");
        this.node0 = new Node(new Wallet("Lin", CommonUtils.sha1("PK-Lin"), 300));
        this.mnode1 = new MiningNode(new Wallet("Simone", CommonUtils.sha1("PK-Simone"), 100), 10000);
        this.mnode2 = new MiningNode(new Wallet("Luis", CommonUtils.sha1("PK-Luis"), 50), 10000);
        this.net3 = new Subnet(this.mnode1, this.mnode2);
        this.mnode4 = new MiningNode(new Wallet("Antonio", CommonUtils.sha1("PK-Antonio"), 400), 10000);

        try {
            this.network.connect(net3).connect(node0).connect(mnode4);
        }
        catch (NodeConnectionException e) {
            System.err.println(e);
        }

        System.out.println(this.mnode2.fullName());
        System.out.println(this.mnode4);
        try {
            this.tr1 = new Transaction(this.mnode1.getWallet(), this.mnode2.getWallet(), 50);
        }
        catch (TransactionException e) {
            System.err.println(e);
        }
    }

    /**
     * Main que se ejecuta y se chequean las salidas
     * 
     * @param args las entrada de main
     */
    public static void main(String args[]) {
        OwnTesterExercise1 tester1 = new OwnTesterExercise1();
        tester1.initialize();
        System.out.println("End");
    }
}