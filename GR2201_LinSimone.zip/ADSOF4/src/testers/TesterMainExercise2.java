package testers;

import blockchain.*;
import exception.*;

/**
 * Clase para probar el ejercicio 2
 * 
 * @author eps
 */
public class TesterMainExercise2 extends TesterMainExercise1{
    /**
     * Prueba del ejercicio 2
     */
    public void buildFaultyNetwork() {
    super.buildNetwork();

        try {
            this.network.connect(this.node); // cannot connect: node already in the network
        } catch (NodeConnectionException e) {
            System.err.println(e);
        }

        try {
            this.network.connect(this.miningNode2); // cannot connect: miningNode in a subnet
        } catch (NodeConnectionException e) {
            System.err.println(e);
        }
    }

    /**
     * Prueba las excepcion de transacciones
     */
    public void createTransactions() {
        try {
            Transaction tr1 = node.createTransaction(wallet2, 10);
            network.broadcast(new TransactionNotification(tr1));
            Transaction tr2 = miningNode.createTransaction(wallet1.getPublicKey(), -1);// negative fails
            network.broadcast(new TransactionNotification(tr2));
        } catch (TransactionException e) {
            System.err.println(e);
        }
    }

    /**
     * Main que se ejecuta
     * 
     * @param args entradas de main
     */
    public static void main(String[] args) {
        TesterMainExercise2 tme = new TesterMainExercise2();
        tme.buildFaultyNetwork();
        tme.createTransactions();
    }
}
    
