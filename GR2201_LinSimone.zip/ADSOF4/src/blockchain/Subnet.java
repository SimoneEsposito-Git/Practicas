package blockchain;

import java.util.*;

import javax.swing.Icon;

import exception.*;

/**
 * Una subred contiene los nodos
 * 
 * @author Lin Qi y Simone Esposito
 */
public class Subnet extends BlockchainElement {
    private List<Node> nodos = new ArrayList<>();

    /**
     * Constructor de subred que reciben unos nodos
     * 
     * @param nodos los nodos de la subred
     */
    public Subnet(Node... nodos) {
        for (Node nodo: nodos) {
            if (nodo.getParent() == null) {
                this.nodos.add(nodo);
                nodo.setPadre(this);
            }
        }
    }

    /**
     * Distribuye el mensaje a sus nodos
     * 
     * @param msg el mensaje que va a procesar
     */
    @Override
    public void broadcast(IMessage msg) {
        System.out.println("[Subnet#"+this.getId()+"] "+msg.getMessage());
        System.out.println("Broadcasting to "+this.nodos.size()+" nodes:");
        for (Node nodo: this.nodos) {
            nodo.broadcast(msg);
        }
    }

    /**
     * Devuelve la informacion de una subred
     * 
     * @return un string que contiene la informacion de una subred
     */
    @Override
    public String toString() {
        String str = "Node network of "+nodos.size()+" nodes:";
        for (Node node: this.nodos) {
            str += " ["+node.toString()+"]";
        }
        return str;
    }
}
