package blockchain.utils;

/**
 * Clase que ofrece atributos por defecto
 * 
 * @author eps
 */
public class BlockConfig {
	/**
	 * Bloque genesis
	 */
	public static String GENESIS_BLOCK = "0000000000000000000000000000000000000000000000000000000000000000";
	/**
	 * Dificultad
	 */
	public static int DIFFICULTY = 1;
	/**
	 * Version
	 */
	public static int VERSION = 1;
}
